# Pure-Javascript-Todo-list
Pure Javascript Todo list with browser localstorage functionality. Saves the todolist even if the page reloads.

Check out the demo
http://bit.ly/2uLq35x
